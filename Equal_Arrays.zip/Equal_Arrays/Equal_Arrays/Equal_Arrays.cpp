// Check if two arrays are equal or not, meaning they have the same elements not neccessarly in the same order; 
// note: the arrays have the same size

using namespace std;

#include <iostream>
#include <vector>
#include <unordered_map>

class Solution {
public:
    bool check(vector<int> A, vector<int> B, int N) {
        //code here
        unordered_map<int, int> hash1;
        for (int i = 0; i < A.size(); i++)
            hash1[A[i]]++;
        unordered_map<int, int> hash2;
        for (int i = 0; i < B.size(); i++)
            hash2[B[i]]++;
        if (hash1 == hash2)
        {
            return true;
        }
        return false;
    }
};

int main()
{
    Solution s1;
    cout << "Type in the size of the arrays: ";
    int N;
    cin >> N;

    cout << "The first array: ";
    vector<int> A;
    int a;
    for (int i = 0; i < N; i++)
    {
        cin >> a;
        A.push_back(a);
    }

    cout << "The second array: ";
    vector<int> B;
    int b;
    for (int i = 0; i < N; i++)
    {
        cin >> b;
        B.push_back(b);
    }
    if (s1.check(A, B, N))
    {
        cout << "The 2 arrays are equal";
    }
    else
    {
        cout << "The 2 arrays are not equal";
    }


}